from django.apps import AppConfig


class FiboConfig(AppConfig):
    name = 'fibo'
