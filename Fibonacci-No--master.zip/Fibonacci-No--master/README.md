# Fibonacci-No

>Fibonacci series up to N element

>Made using Python, Django, jinja2 and Html+Css.

>Just for learn, how to use Django in Python.

>Input Image

![alt text](https://github.com/raharongit/Fibonacci-No-/blob/master/fibonacci/fibo/static/fibo/images/input.png "Input")

>Output Image

![alt text](https://github.com/raharongit/Fibonacci-No-/blob/master/fibonacci/fibo/static/fibo/images/output.png "Output")
